package com.ibm.jp.test;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;

@SessionScoped
public class MyObject implements Serializable {
	private static final long serialVersionUID = 8257261434327004664L;
	private String str;
	
	/**
	 * 
	 */
	public MyObject() {
		this.str = "";
	}
	
	/**
	 * 
	 */
	public String getStr() {
		return str;
	}
	
	/**
	 * 
	 */
	public void setStr(String str) {
		System.out.println("MyObject: setStr() \"" + this.str + "\" -> \"" + str + "\")");
		this.str = str;
	}

}
